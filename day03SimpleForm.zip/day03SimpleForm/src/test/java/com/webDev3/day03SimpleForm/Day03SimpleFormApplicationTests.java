package com.webDev3.day03SimpleForm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day03SimpleFormApplicationTests {

	@Test
	void contextLoads() {
	}

}
