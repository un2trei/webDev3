package com.webDev3.day03SimpleForm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day03SimpleFormApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day03SimpleFormApplication.class, args);
	}

}
