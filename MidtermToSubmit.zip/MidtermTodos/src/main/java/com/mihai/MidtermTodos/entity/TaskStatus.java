package com.mihai.MidtermTodos.entity;

public enum TaskStatus {
    PENDING,
    DONE
}
