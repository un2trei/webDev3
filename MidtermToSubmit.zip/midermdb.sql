SELECT * FROM myblogapp.users;
use simpleformdb;
create database midtermdb;
use midtermdb;